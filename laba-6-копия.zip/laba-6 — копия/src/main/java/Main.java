import libraries.FileDownload;
import libraries.FilePathGetter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        FilePathGetter getter = new FilePathGetter();
        String pageAddress = String.format("https://tsutmb.ru/institutes/imfit/obuchenie/raspisanie/raspisanie-uchebnykh-zanyatiy/");
        String downloadFolderName = "Download";
        try {
            download(pageAddress, downloadFolderName, getter);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void download(String pageAddress, String downloadFolderName, FilePathGetter getter) throws IOException {
        Map<String, String> documentsLinks = getter.getDocumentsLinks(pageAddress, "https://tsutmb.ru/", "UTF-8", true);
        List<String> errorList = new ArrayList<>(); // Очищаем список ошибок перед каждой новой итерацией
        FileDownload downloader = new FileDownload();
        String currentDir = System.getProperty("user.dir") + "/";
        errorList.add(String.format("Не удалось скачать файлы с %s:\n", pageAddress));
    
        for (Map.Entry<String, String> entry : documentsLinks.entrySet()) {
            String filePath = currentDir + "/" + downloadFolderName + "/" + entry.getValue().replace("\t", "") + "1/";
            File directory = new File(filePath);
            if (!directory.exists()) {
                directory.mkdirs();
            }
    
            try {
                boolean isDownloaded = downloader.downloadFile(filePath, entry.getKey().replace("\t", ""));
                if (isDownloaded) {
                    System.out.println("Файл успешно загружен: " + entry.getValue());
                } else {
                    errorList.add(entry.getValue() + " = " + entry.getKey() + " = Не удалось загрузить файл.\n");
                }
            } catch (IOException e) {
                errorList.add(entry.getValue() + " = " + entry.getKey() + " = " + e.getMessage() + "\n");
            }
        }
    
        {// Сохраняем ошибки в файл
            FileWriter writer = new FileWriter(currentDir + "/" + downloadFolderName + "/" + "error.txt");
            for (String str : errorList) {
                writer.write(str);
            }
            writer.close();
        }
    
        downloader = null;
    }
}
